## KNTNBOTWA
BOT WHATSAPP YANG BISA DIGUNAKAN DI TERMUX







## CARA INSTALL
# TERMUX
```bash
> download termux
> buka
> pkg install git
> pkg install ffmpeg
> pkg install nodejs
> apt update && apt upgrade
> git clone https://github.com/benisadewa/kntnbotwa
> cd kntnbotwa
> npm i -g cwebp && npm i -g ytdl
> npm i && npm i got
> bash install.sh
> node index.js
```


# FITUR

| KEADAAN       |               FITUR     |
| :-----------: | :--------------------------------:  |
|       ✅       |    PANTUN                         |
|       ✅       | ANIMEPICT                         |
|       ✅       | STICKER                           |
|       ✅       | NULIS                             |
|       ✅       | QUOTES                            |
|       ✅       | RANDOM PICT                       |
|       ✅       | ANIMEPICT                         |
|       ✅       | LIRIK                             |
|       ✅       | ALAY                              |
|       ✅       | YT,YTMP3,IG,TWT DOWNLOADER        |
|       ✅       | WIKIPEDIA                         |
|       ✅       | ARTI NAMA                         |
|       ✅       | SHOLAT                            |
|       ✅       | QURAN                             |
|       ✅       | KAMING SUN                        |

ket : ✅ : aktif




## THANKS TO
* [`termux-whatsapp-bot`](https://github.com/fdciabdul/termux-whatsapp-bot)

## DONASI
* Gopay : 081271699856 Reuz
